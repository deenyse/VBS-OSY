char *genWord();
char *genLine(int words_amount);
